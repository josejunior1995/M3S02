package br.com.canasvieiras.m3s02projetorevisao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M3s02ProjetorevisaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
