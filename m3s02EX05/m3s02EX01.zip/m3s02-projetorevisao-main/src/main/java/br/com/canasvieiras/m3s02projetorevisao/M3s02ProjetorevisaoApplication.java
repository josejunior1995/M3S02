package br.com.canasvieiras.m3s02projetorevisao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M3s02ProjetorevisaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(M3s02ProjetorevisaoApplication.class, args);
	}

}
